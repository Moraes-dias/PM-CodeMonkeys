
  # Pokédex Homepage Design

  This is a code bundle for Pokédex Homepage Design. The original project is available at https://www.figma.com/design/oaICasm85sEgk6dBaPzZ6N/Pok%C3%A9dex-Homepage-Design.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  