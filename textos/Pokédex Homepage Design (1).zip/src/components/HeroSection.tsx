import { Search } from "lucide-react";
import { Button } from "./ui/button";
import { Input } from "./ui/input";

export function HeroSection() {
  return (
    <main className="relative min-h-[calc(100vh-4rem)] flex items-center justify-center overflow-hidden">
      {/* Background Image with Overlay */}
      <div 
        className="absolute inset-0 bg-cover bg-center bg-no-repeat"
        style={{ 
          backgroundImage: "url('https://images8.alphacoders.com/723/thumb-1920-723290.jpg')" 
        }}
      >
        <div className="absolute inset-0 bg-black/40"></div>
      </div>

      {/* Left Pokédex Border */}
      <div className="absolute left-0 top-0 bottom-0 w-16 sm:w-24 lg:w-32 bg-gradient-to-r from-red-600 via-red-500 to-red-600 z-20">
        <div className="h-full bg-gradient-to-b from-red-400/30 via-transparent to-red-800/30 relative">
          {/* Pokéball detail on left border */}
          <div className="absolute top-1/2 left-1/2 transform -translate-x-1/2 -translate-y-1/2">
            <div className="w-8 h-8 sm:w-10 sm:h-10 bg-white rounded-full border-2 border-black flex items-center justify-center relative shadow-lg">
              <div className="w-3 h-3 sm:w-4 sm:h-4 bg-black rounded-full border border-white"></div>
              <div className="absolute top-1/2 left-0 right-0 h-0.5 bg-black transform -translate-y-1/2"></div>
            </div>
          </div>
          {/* Decorative elements */}
          <div className="absolute top-1/4 left-1/2 w-2 h-2 bg-yellow-400 rounded-full transform -translate-x-1/2 shadow-sm"></div>
          <div className="absolute top-3/4 left-1/2 w-1.5 h-1.5 bg-blue-400 rounded-full transform -translate-x-1/2 shadow-sm"></div>
        </div>
      </div>

      {/* Right Pokédex Border */}
      <div className="absolute right-0 top-0 bottom-0 w-16 sm:w-24 lg:w-32 bg-gradient-to-l from-red-600 via-red-500 to-red-600 z-20">
        <div className="h-full bg-gradient-to-b from-red-400/30 via-transparent to-red-800/30 relative">
          {/* Pokéball detail on right border */}
          <div className="absolute top-1/2 left-1/2 transform -translate-x-1/2 -translate-y-1/2">
            <div className="w-8 h-8 sm:w-10 sm:h-10 bg-white rounded-full border-2 border-black flex items-center justify-center relative shadow-lg">
              <div className="w-3 h-3 sm:w-4 sm:h-4 bg-black rounded-full border border-white"></div>
              <div className="absolute top-1/2 left-0 right-0 h-0.5 bg-black transform -translate-y-1/2"></div>
            </div>
          </div>
          {/* Decorative elements */}
          <div className="absolute top-1/3 left-1/2 w-1.5 h-1.5 bg-green-400 rounded-full transform -translate-x-1/2 shadow-sm"></div>
          <div className="absolute top-2/3 left-1/2 w-2 h-2 bg-yellow-400 rounded-full transform -translate-x-1/2 shadow-sm"></div>
        </div>
      </div>

      {/* Content */}
      <div className="relative z-10 text-center max-w-4xl mx-auto px-20 sm:px-28 lg:px-36">
        {/* Pokéball Icon */}
        <div className="mb-8 flex justify-center">
          <div className="w-16 h-16 bg-white rounded-full border-4 border-black flex items-center justify-center relative">
            <div className="w-6 h-6 bg-black rounded-full border-2 border-white"></div>
            <div className="absolute top-1/2 left-0 right-0 h-1 bg-black transform -translate-y-1/2"></div>
          </div>
        </div>

        {/* Title with Pokédex-inspired typography */}
        <h1 className="text-6xl sm:text-7xl lg:text-8xl mb-8 tracking-wider text-center">
          <span 
            className="inline-block transform -skew-x-12 text-yellow-300"
            style={{ 
              fontFamily: 'Impact, Arial Black, sans-serif',
              textShadow: `
                4px 4px 0px #000,
                -2px -2px 0px #000,
                2px -2px 0px #000,
                -2px 2px 0px #000,
                0px 4px 0px #000,
                4px 0px 0px #000,
                0px -2px 0px #000,
                -4px 0px 0px #000,
                2px 2px 8px rgba(0,0,0,0.8)
              `,
              WebkitTextStroke: '2px #000',
              color: '#fde047',
              filter: 'drop-shadow(0 0 20px rgba(253, 224, 71, 0.6))'
            }}
          >
            POKÉDEX
          </span>
        </h1>

        {/* Pokédex-style Search Bar */}
        <div className="max-w-2xl mx-auto">
          <div className="relative">
            {/* Search container with Pokédex styling */}
            <div className="bg-gradient-to-r from-gray-800 via-gray-700 to-gray-800 p-3 rounded-2xl border-4 border-black shadow-2xl">
              <div className="bg-gradient-to-r from-blue-900 via-blue-800 to-blue-900 p-2 rounded-xl border-2 border-blue-600">
                <div className="flex items-center space-x-2">
                  {/* LED indicator */}
                  <div className="w-3 h-3 bg-green-400 rounded-full border border-green-600 shadow-inner animate-pulse"></div>
                  
                  {/* Input field */}
                  <Input
                    type="text"
                    placeholder="BUSCAR POKÉMON POR NOME OU NÚMERO"
                    className="flex-1 h-10 text-sm pl-3 pr-3 bg-black/80 text-green-400 placeholder-green-600/70 border border-green-600 rounded-lg shadow-inner focus:border-green-400 focus:ring-1 focus:ring-green-400/50 font-mono uppercase tracking-wider"
                    style={{ 
                      fontFamily: 'Courier New, monospace',
                      textShadow: '0 0 2px currentColor'
                    }}
                  />
                  
                  {/* Search button */}
                  <Button
                    size="icon"
                    className="h-10 w-10 bg-red-600 hover:bg-red-700 rounded-lg shadow-md border-2 border-red-800 transition-all duration-200 hover:scale-105"
                  >
                    <Search className="w-4 h-4 text-white" />
                  </Button>
                </div>
                
                {/* Additional Pokédex details */}
                <div className="flex justify-between items-center mt-2 px-1">
                  <div className="flex space-x-1">
                    <div className="w-1.5 h-1.5 bg-yellow-400 rounded-full"></div>
                    <div className="w-1.5 h-1.5 bg-red-400 rounded-full"></div>
                    <div className="w-1.5 h-1.5 bg-blue-400 rounded-full"></div>
                  </div>
                  <div className="text-xs text-green-400/70 font-mono">
                    [ READY ]
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>

        {/* Subtitle */}
        <p className="mt-6 text-xl text-white/90 drop-shadow-lg font-mono tracking-wide">
          &gt; DESCUBRA O MUNDO DOS POKÉMON_
        </p>
      </div>
    </main>
  );
}