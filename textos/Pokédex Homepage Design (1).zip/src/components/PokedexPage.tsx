import React, { useState, useEffect } from 'react';
import { PokedexExterior } from './PokedexExterior';
import { PokedexScreen } from './PokedexScreen';
import { SettingsPanel } from './SettingsPanel';
import { PokedexBackButton } from './PokedexBackButton';
import { mockPokemonData } from './mockPokemonData';

interface PokedexPageProps {
  onBack?: () => void;
}

export function PokedexPage({ onBack }: PokedexPageProps) {
  const [currentPokemon, setCurrentPokemon] = useState(mockPokemonData[0]);
  const [searchQuery, setSearchQuery] = useState('');
  const [showSettings, setShowSettings] = useState(false);
  const [darkMode, setDarkMode] = useState(false);
  const [volume, setVolume] = useState(50);
  const [musicEnabled, setMusicEnabled] = useState(false);
  const [filteredPokemon, setFilteredPokemon] = useState(mockPokemonData);

  useEffect(() => {
    if (darkMode) {
      document.documentElement.classList.add('dark');
    } else {
      document.documentElement.classList.remove('dark');
    }
  }, [darkMode]);

  useEffect(() => {
    const filtered = mockPokemonData.filter(pokemon =>
      pokemon.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
      pokemon.id.toString().includes(searchQuery)
    );
    setFilteredPokemon(filtered);
  }, [searchQuery]);

  const handleRandomPokemon = () => {
    const randomIndex = Math.floor(Math.random() * mockPokemonData.length);
    setCurrentPokemon(mockPokemonData[randomIndex]);
  };

  const handleSearch = (query: string) => {
    setSearchQuery(query);
  };

  const handleSettingsToggle = () => {
    setShowSettings(!showSettings);
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-purple-200 via-purple-100 to-purple-300 dark:from-purple-900 dark:via-purple-800 dark:to-purple-900 p-4">
      {onBack && <PokedexBackButton onBack={onBack} />}
      <div className="max-w-6xl mx-auto">
        <div className="bg-gradient-to-b from-red-600 to-red-700 rounded-3xl p-6 shadow-2xl">
          {/* Pokedex Header */}
          <div className="flex items-center justify-between mb-6">
            <div className="flex items-center gap-4">
              <div className="w-12 h-12 bg-cyan-400 rounded-full border-4 border-cyan-300 shadow-inner"></div>
              <div className="flex gap-2">
                <div className="w-4 h-4 bg-red-400 rounded-full"></div>
                <div className="w-4 h-4 bg-yellow-400 rounded-full"></div>
                <div className="w-4 h-4 bg-green-400 rounded-full"></div>
              </div>
            </div>
            <h1 className="text-white text-2xl">POKÉDEX</h1>
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-4 gap-4">
            {/* Left side - Controls */}
            <div className="lg:col-span-1">
              <PokedexExterior
                onRandomPokemon={handleRandomPokemon}
                onSearch={handleSearch}
                onSettingsToggle={handleSettingsToggle}
                musicEnabled={musicEnabled}
                setMusicEnabled={setMusicEnabled}
              />
            </div>

            {/* Right side - Screen */}
            <div className="lg:col-span-3">
              <PokedexScreen
                currentPokemon={currentPokemon}
                setCurrentPokemon={setCurrentPokemon}
                filteredPokemon={filteredPokemon}
                searchQuery={searchQuery}
              />
            </div>
          </div>
        </div>

        {/* Settings Panel */}
        {showSettings && (
          <SettingsPanel
            isOpen={showSettings}
            onClose={() => setShowSettings(false)}
            darkMode={darkMode}
            setDarkMode={setDarkMode}
            volume={volume}
            setVolume={setVolume}
            musicEnabled={musicEnabled}
            setMusicEnabled={setMusicEnabled}
          />
        )}
      </div>
    </div>
  );
}