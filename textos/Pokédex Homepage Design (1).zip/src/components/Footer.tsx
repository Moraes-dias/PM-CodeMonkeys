export function Footer() {
  return (
    <footer className="bg-gray-900 text-white py-6 relative z-30">
      <div className="max-w-7xl mx-auto px-20 sm:px-28 lg:px-36">
        <div className="text-center">
          <p className="text-gray-300 mb-4">
            Projeto Pokédex – Desenvolvido para estudos de HTML, CSS e JavaScript.
          </p>
          <div className="flex justify-center space-x-6">
            <a 
              href="#" 
              className="text-gray-400 hover:text-white transition-colors duration-200"
            >
              Sobre
            </a>
            <span className="text-gray-600">|</span>
            <a 
              href="#" 
              className="text-gray-400 hover:text-white transition-colors duration-200"
            >
              Contato
            </a>
            <span className="text-gray-600">|</span>
            <a 
              href="#" 
              className="text-gray-400 hover:text-white transition-colors duration-200"
            >
              Github
            </a>
          </div>
        </div>
      </div>
    </footer>
  );
}