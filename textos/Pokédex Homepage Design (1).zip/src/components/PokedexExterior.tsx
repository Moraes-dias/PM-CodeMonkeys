import React from 'react';
import { Search, Shuffle, Settings, Volume2, VolumeX } from 'lucide-react';
import { Button } from './ui/button';
import { Input } from './ui/input';

interface PokedexExteriorProps {
  onRandomPokemon: () => void;
  onSearch: (query: string) => void;
  onSettingsToggle: () => void;
  musicEnabled: boolean;
  setMusicEnabled: (enabled: boolean) => void;
}

export function PokedexExterior({
  onRandomPokemon,
  onSearch,
  onSettingsToggle,
  musicEnabled,
  setMusicEnabled
}: PokedexExteriorProps) {
  const [searchValue, setSearchValue] = React.useState('');

  const handleSearchSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    onSearch(searchValue);
  };

  const handleSearchChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const value = e.target.value;
    setSearchValue(value);
    onSearch(value);
  };

  return (
    <div className="bg-gradient-to-b from-red-500 to-red-600 rounded-2xl p-4 border-4 border-red-800 shadow-lg">
      {/* Control Panel */}
      <div className="space-y-4">
        {/* Search Input */}
        <form onSubmit={handleSearchSubmit} className="space-y-2">
          <div className="relative">
            <Input
              type="text"
              placeholder="Buscar Pokémon..."
              value={searchValue}
              onChange={handleSearchChange}
              className="w-full bg-gray-800 text-white border-2 border-gray-600 rounded-lg focus:border-purple-400"
            />
            <Button
              type="submit"
              size="icon"
              className="absolute right-1 top-1 h-8 w-8 bg-purple-500 hover:bg-purple-600"
            >
              <Search className="w-4 h-4" />
            </Button>
          </div>
        </form>

        {/* Control Buttons */}
        <div className="grid grid-cols-1 gap-2">
          <Button
            onClick={onRandomPokemon}
            className="w-full bg-yellow-500 hover:bg-yellow-600 text-black font-mono text-sm"
          >
            <Shuffle className="w-4 h-4 mr-2" />
            ALEATÓRIO
          </Button>

          <Button
            onClick={onSettingsToggle}
            className="w-full bg-gray-600 hover:bg-gray-700 text-white font-mono text-sm"
          >
            <Settings className="w-4 h-4 mr-2" />
            CONFIG
          </Button>

          <Button
            onClick={() => setMusicEnabled(!musicEnabled)}
            className="w-full bg-purple-500 hover:bg-purple-600 text-white font-mono text-sm"
          >
            {musicEnabled ? (
              <Volume2 className="w-4 h-4 mr-2" />
            ) : (
              <VolumeX className="w-4 h-4 mr-2" />
            )}
            {musicEnabled ? 'SOM ON' : 'SOM OFF'}
          </Button>
        </div>

        {/* Decorative Elements */}
        <div className="mt-6 space-y-2">
          <div className="flex justify-center space-x-2">
            <div className="w-3 h-3 bg-yellow-400 rounded-full"></div>
            <div className="w-3 h-3 bg-green-400 rounded-full"></div>
            <div className="w-3 h-3 bg-red-400 rounded-full"></div>
          </div>
          
          <div className="bg-gray-800 rounded-lg p-2">
            <div className="grid grid-cols-4 gap-1">
              {Array.from({ length: 8 }).map((_, i) => (
                <div
                  key={i}
                  className="w-2 h-2 bg-gray-600 rounded-full"
                ></div>
              ))}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}