import React, { useState } from 'react';
import { ChevronLeft, ChevronRight, Grid, Eye } from 'lucide-react';
import { Button } from './ui/button';
import { Card } from './ui/card';
import { Badge } from './ui/badge';
import { Progress } from './ui/progress';
import { PokemonGrid } from './PokemonGrid';
import { Pokemon } from './mockPokemonData';

interface PokedexScreenProps {
  currentPokemon: Pokemon;
  setCurrentPokemon: (pokemon: Pokemon) => void;
  filteredPokemon: Pokemon[];
  searchQuery: string;
}

export function PokedexScreen({
  currentPokemon,
  setCurrentPokemon,
  filteredPokemon,
  searchQuery
}: PokedexScreenProps) {
  const [viewMode, setViewMode] = useState<'grid' | 'detail'>('grid');
  const getTypeColor = (type: string) => {
    const colors: Record<string, string> = {
      Fire: 'bg-red-500',
      Water: 'bg-blue-500',
      Grass: 'bg-green-500',
      Electric: 'bg-yellow-500',
      Poison: 'bg-purple-500',
      Flying: 'bg-indigo-400',
      Normal: 'bg-gray-500',
      Fighting: 'bg-red-700',
      Ground: 'bg-yellow-600',
      Rock: 'bg-yellow-800',
      Bug: 'bg-green-400',
      Ghost: 'bg-purple-700',
      Steel: 'bg-gray-600',
      Psychic: 'bg-pink-500',
      Ice: 'bg-blue-300',
      Dragon: 'bg-purple-600',
      Dark: 'bg-gray-800',
      Fairy: 'bg-pink-300'
    };
    return colors[type] || 'bg-gray-500';
  };

  const currentIndex = filteredPokemon.findIndex(p => p.id === currentPokemon.id);
  const canGoPrev = currentIndex > 0;
  const canGoNext = currentIndex < filteredPokemon.length - 1;

  const handlePrevious = () => {
    if (canGoPrev) {
      setCurrentPokemon(filteredPokemon[currentIndex - 1]);
    }
  };

  const handleNext = () => {
    if (canGoNext) {
      setCurrentPokemon(filteredPokemon[currentIndex + 1]);
    }
  };

  return (
    <div className="bg-gradient-to-b from-purple-400 to-purple-500 rounded-2xl p-4 border-4 border-purple-600 shadow-lg">
      {/* View Mode Toggle */}
      <div className="flex justify-center mb-4">
        <div className="bg-gray-800 rounded-lg p-1 flex">
          <Button
            onClick={() => setViewMode('grid')}
            size="sm"
            className={`flex items-center gap-2 ${
              viewMode === 'grid' 
                ? 'bg-purple-500 text-white hover:bg-purple-600' 
                : 'bg-transparent text-gray-400 hover:bg-gray-700'
            }`}
          >
            <Grid className="w-4 h-4" />
            Grade
          </Button>
          <Button
            onClick={() => setViewMode('detail')}
            size="sm"
            className={`flex items-center gap-2 ${
              viewMode === 'detail' 
                ? 'bg-purple-500 text-white hover:bg-purple-600' 
                : 'bg-transparent text-gray-400 hover:bg-gray-700'
            }`}
          >
            <Eye className="w-4 h-4" />
            Detalhes
          </Button>
        </div>
      </div>

      {/* Main Screen */}
      {viewMode === 'grid' ? (
        <PokemonGrid
          pokemon={filteredPokemon}
          onPokemonSelect={(pokemon) => {
            setCurrentPokemon(pokemon);
            setViewMode('detail');
          }}
          selectedPokemon={currentPokemon}
        />
      ) : (
        <div className="bg-gray-900 rounded-xl p-4 border-2 border-gray-700 min-h-[500px]">
        
        {/* Navigation Controls */}
        <div className="flex justify-between items-center mb-4">
          <Button
            onClick={handlePrevious}
            disabled={!canGoPrev}
            size="icon"
            className="bg-gray-700 hover:bg-gray-600 disabled:opacity-50"
          >
            <ChevronLeft className="w-4 h-4" />
          </Button>
          
          <div className="text-green-400 font-mono text-sm">
            #{currentPokemon.id.toString().padStart(3, '0')}
          </div>
          
          <Button
            onClick={handleNext}
            disabled={!canGoNext}
            size="icon"
            className="bg-gray-700 hover:bg-gray-600 disabled:opacity-50"
          >
            <ChevronRight className="w-4 h-4" />
          </Button>
        </div>

        {/* Pokemon Display */}
        <div className="text-center mb-4">
          <img
            src={currentPokemon.image}
            alt={currentPokemon.name}
            className="w-48 h-48 mx-auto object-contain bg-gradient-to-br from-white/10 to-white/5 rounded-xl border border-white/20 p-4"
          />
        </div>

        {/* Pokemon Info */}
        <div className="space-y-3">
          <div className="text-center">
            <h2 className="text-2xl text-green-400 font-mono uppercase tracking-wider">
              {currentPokemon.name}
            </h2>
          </div>

          {/* Types */}
          <div className="flex justify-center space-x-2">
            {currentPokemon.type.map((type) => (
              <Badge
                key={type}
                className={`${getTypeColor(type)} text-white px-3 py-1`}
              >
                {type}
              </Badge>
            ))}
          </div>

          {/* Physical Stats */}
          <div className="grid grid-cols-2 gap-4 text-green-400 font-mono text-sm">
            <div className="bg-gray-800 rounded-lg p-2">
              <div className="text-gray-400">HEIGHT</div>
              <div>{currentPokemon.height}</div>
            </div>
            <div className="bg-gray-800 rounded-lg p-2">
              <div className="text-gray-400">WEIGHT</div>
              <div>{currentPokemon.weight}</div>
            </div>
          </div>

          {/* Description */}
          <div className="bg-gray-800 rounded-lg p-3">
            <div className="text-gray-400 text-sm mb-1">DESCRIPTION</div>
            <div className="text-green-400 font-mono text-sm leading-relaxed">
              {currentPokemon.description}
            </div>
          </div>

          {/* Battle Stats */}
          <div className="bg-gray-800 rounded-lg p-3">
            <div className="text-gray-400 text-sm mb-3">BATTLE STATS</div>
            <div className="space-y-2">
              {Object.entries(currentPokemon.stats).map(([stat, value]) => (
                <div key={stat}>
                  <div className="flex justify-between text-xs text-green-400 font-mono mb-1">
                    <span>{stat.toUpperCase()}</span>
                    <span>{value}</span>
                  </div>
                  <Progress value={value} className="h-2" />
                </div>
              ))}
            </div>
          </div>
        </div>
        </div>
      )}
    </div>
  );
}