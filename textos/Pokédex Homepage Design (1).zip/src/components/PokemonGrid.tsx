import React from 'react';
import { PokemonCard } from './PokemonCard';
import { Pokemon } from './mockPokemonData';

interface PokemonGridProps {
  pokemon: Pokemon[];
  onPokemonSelect: (pokemon: Pokemon) => void;
  selectedPokemon?: Pokemon;
}

export function PokemonGrid({ pokemon, onPokemonSelect, selectedPokemon }: PokemonGridProps) {
  if (pokemon.length === 0) {
    return (
      <div className="bg-gray-900 rounded-xl p-8 border-2 border-gray-700 min-h-[500px] flex items-center justify-center">
        <div className="text-center">
          <div className="text-green-400 font-mono text-lg mb-2">NENHUM POKÉMON ENCONTRADO</div>
          <div className="text-gray-400 font-mono text-sm">Tente uma busca diferente</div>
        </div>
      </div>
    );
  }

  return (
    <div className="bg-gray-900 rounded-xl p-4 border-2 border-gray-700 min-h-[500px]">
      {/* Header */}
      <div className="text-center mb-4">
        <div className="text-green-400 font-mono text-lg">POKÉDX DATABASE</div>
        <div className="text-gray-400 font-mono text-sm">
          {pokemon.length} Pokémon encontrados
        </div>
      </div>
      
      {/* Pokemon Grid */}
      <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5 xl:grid-cols-6 gap-3 max-h-[400px] overflow-y-auto scrollbar-thin scrollbar-thumb-purple-500 scrollbar-track-gray-600">
        {pokemon.map((poke) => (
          <PokemonCard
            key={poke.id}
            pokemon={poke}
            onClick={() => onPokemonSelect(poke)}
            isSelected={selectedPokemon?.id === poke.id}
          />
        ))}
      </div>
      
      {/* Selected Pokemon Preview */}
      {selectedPokemon && (
        <div className="mt-4 p-4 bg-gray-800 rounded-lg border border-gray-600">
          <div className="flex items-center gap-4">
            <img
              src={selectedPokemon.image}
              alt={selectedPokemon.name}
              className="w-16 h-16 object-contain bg-gradient-to-br from-white/10 to-white/5 rounded-lg border border-white/20 p-2"
            />
            <div className="flex-1">
              <div className="text-green-400 font-mono">
                #{selectedPokemon.id.toString().padStart(3, '0')} - {selectedPokemon.name.toUpperCase()}
              </div>
              <div className="text-gray-400 font-mono text-sm mt-1">
                {selectedPokemon.description.slice(0, 100)}...
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}