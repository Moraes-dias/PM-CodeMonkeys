import { Home, Book, CreditCard, Map, Heart, User } from "lucide-react";
import { Button } from "./ui/button";

interface HeaderProps {
  currentPage?: 'home' | 'pokedex';
  setCurrentPage?: (page: 'home' | 'pokedex') => void;
}

export function Header({ currentPage = 'home', setCurrentPage }: HeaderProps) {
  const navItems = [
    { name: "Home", icon: Home, page: 'home' as const },
    { name: "Pokédx", icon: Book, page: 'pokedex' as const },
    { name: "Cartas", icon: CreditCard, page: 'cards' as const },
    { name: "Região", icon: Map, page: 'region' as const },
    { name: "Favoritos", icon: Heart, page: 'favorites' as const },
  ];

  return (
    <header className="bg-red-600 border-b-4 border-black shadow-lg relative z-30">
      <div className="max-w-7xl mx-auto px-20 sm:px-28 lg:px-36">
        <div className="flex items-center justify-between h-16">
          {/* Navigation Menu */}
          <nav className="flex space-x-1">
            {navItems.map((item) => {
              const isActive = (item.page === 'home' && currentPage === 'home') || 
                              (item.page === 'pokedex' && currentPage === 'pokedex');
              
              return (
                <Button
                  key={item.name}
                  variant={isActive ? "secondary" : "ghost"}
                  onClick={() => {
                    if (setCurrentPage && (item.page === 'home' || item.page === 'pokedex')) {
                      setCurrentPage(item.page);
                    }
                  }}
                  className={`flex items-center space-x-2 px-4 py-2 rounded-lg transition-colors ${
                    isActive 
                      ? "bg-white text-red-600 hover:bg-gray-100" 
                      : "text-white hover:bg-red-700 hover:text-white"
                  }`}
                >
                  <item.icon className="w-4 h-4" />
                  <span className="hidden sm:inline">{item.name}</span>
                </Button>
              );
            })}
          </nav>

          {/* User Profile */}
          <Button
            variant="ghost"
            size="icon"
            className="rounded-full bg-white text-red-600 hover:bg-gray-100 w-10 h-10"
          >
            <User className="w-5 h-5" />
          </Button>
        </div>
      </div>
    </header>
  );
}