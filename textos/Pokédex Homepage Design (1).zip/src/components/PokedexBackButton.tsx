import { ArrowLeft } from 'lucide-react';
import { Button } from './ui/button';

interface PokedexBackButtonProps {
  onBack: () => void;
}

export function PokedexBackButton({ onBack }: PokedexBackButtonProps) {
  return (
    <div className="fixed top-4 left-4 z-50">
      <Button
        onClick={onBack}
        className="bg-red-600 hover:bg-red-700 text-white shadow-lg"
      >
        <ArrowLeft className="w-4 h-4 mr-2" />
        Voltar
      </Button>
    </div>
  );
}