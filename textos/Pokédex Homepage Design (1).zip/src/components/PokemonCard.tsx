import React from 'react';
import { Card } from './ui/card';
import { Badge } from './ui/badge';
import { Pokemon } from './mockPokemonData';

interface PokemonCardProps {
  pokemon: Pokemon;
  onClick: () => void;
  isSelected?: boolean;
}

export function PokemonCard({ pokemon, onClick, isSelected = false }: PokemonCardProps) {
  const getTypeColor = (type: string) => {
    const colors: Record<string, string> = {
      Fire: 'bg-red-500',
      Water: 'bg-blue-500',
      Grass: 'bg-green-500',
      Electric: 'bg-yellow-500',
      Poison: 'bg-purple-500',
      Flying: 'bg-indigo-400',
      Normal: 'bg-gray-500',
      Fighting: 'bg-red-700',
      Ground: 'bg-yellow-600',
      Rock: 'bg-yellow-800',
      Bug: 'bg-green-400',
      Ghost: 'bg-purple-700',
      Steel: 'bg-gray-600',
      Psychic: 'bg-pink-500',
      Ice: 'bg-blue-300',
      Dragon: 'bg-purple-600',
      Dark: 'bg-gray-800',
      Fairy: 'bg-pink-300'
    };
    return colors[type] || 'bg-gray-500';
  };

  return (
    <Card 
      className={`bg-gray-800 border-2 hover:border-purple-400 cursor-pointer transition-all duration-200 overflow-hidden group hover:scale-105 ${
        isSelected ? 'border-purple-400 bg-gray-700' : 'border-gray-600'
      }`}
      onClick={onClick}
    >
      <div className="p-3">
        {/* Pokemon Number */}
        <div className="text-green-400 font-mono text-xs mb-2">
          #{pokemon.id.toString().padStart(3, '0')}
        </div>
        
        {/* Pokemon Image */}
        <div className="flex justify-center mb-3">
          <img
            src={pokemon.image}
            alt={pokemon.name}
            className="w-20 h-20 object-contain bg-gradient-to-br from-white/10 to-white/5 rounded-lg border border-white/20 p-2"
          />
        </div>
        
        {/* Pokemon Name */}
        <h3 className="text-green-400 font-mono text-center mb-2 uppercase tracking-wide">
          {pokemon.name}
        </h3>
        
        {/* Types */}
        <div className="flex justify-center gap-1 mb-2">
          {pokemon.type.map((type) => (
            <Badge
              key={type}
              className={`${getTypeColor(type)} text-white text-xs px-2 py-1`}
            >
              {type}
            </Badge>
          ))}
        </div>
        
        {/* Quick Stats */}
        <div className="grid grid-cols-2 gap-1 text-xs font-mono">
          <div className="text-center">
            <div className="text-gray-400">HP</div>
            <div className="text-green-400">{pokemon.stats.hp}</div>
          </div>
          <div className="text-center">
            <div className="text-gray-400">ATK</div>
            <div className="text-green-400">{pokemon.stats.attack}</div>
          </div>
        </div>
      </div>
    </Card>
  );
}