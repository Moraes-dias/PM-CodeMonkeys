export interface Pokemon {
  id: number;
  name: string;
  type: string[];
  height: string;
  weight: string;
  description: string;
  image: string;
  stats: {
    hp: number;
    attack: number;
    defense: number;
    speed: number;
  };
}

export const mockPokemonData: Pokemon[] = [
  {
    id: 1,
    name: "Bulbasaur",
    type: ["Grass", "Poison"],
    height: "0.7 m",
    weight: "6.9 kg",
    description: "A strange seed was planted on its back at birth. The plant sprouts and grows with this Pokémon.",
    image: "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/other/official-artwork/1.png",
    stats: {
      hp: 45,
      attack: 49,
      defense: 49,
      speed: 45
    }
  },
  {
    id: 2,
    name: "Ivysaur",
    type: ["Grass", "Poison"],
    height: "1.0 m",
    weight: "13.0 kg",
    description: "When the bulb on its back grows large, it appears to lose the ability to stand on its hind legs.",
    image: "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/other/official-artwork/2.png",
    stats: {
      hp: 60,
      attack: 62,
      defense: 63,
      speed: 60
    }
  },
  {
    id: 3,
    name: "Venusaur",
    type: ["Grass", "Poison"],
    height: "2.0 m",
    weight: "100.0 kg",
    description: "The plant blooms when it is absorbing solar energy. It stays on the move to seek sunlight.",
    image: "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/other/official-artwork/3.png",
    stats: {
      hp: 80,
      attack: 82,
      defense: 83,
      speed: 80
    }
  },
  {
    id: 4,
    name: "Charmander",
    type: ["Fire"],
    height: "0.6 m",
    weight: "8.5 kg",
    description: "Obviously prefers hot places. When it rains, steam is said to spout from the tip of its tail.",
    image: "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/other/official-artwork/4.png",
    stats: {
      hp: 39,
      attack: 52,
      defense: 43,
      speed: 65
    }
  },
  {
    id: 5,
    name: "Charmeleon",
    type: ["Fire"],
    height: "1.1 m",
    weight: "19.0 kg",
    description: "When it swings its burning tail, it elevates the temperature to unbearably hot levels.",
    image: "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/other/official-artwork/5.png",
    stats: {
      hp: 58,
      attack: 64,
      defense: 58,
      speed: 80
    }
  },
  {
    id: 6,
    name: "Charizard",
    type: ["Fire", "Flying"],
    height: "1.7 m",
    weight: "90.5 kg",
    description: "Spits fire that is hot enough to melt boulders. Known to cause forest fires unintentionally.",
    image: "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/other/official-artwork/6.png",
    stats: {
      hp: 78,
      attack: 84,
      defense: 78,
      speed: 100
    }
  },
  {
    id: 7,
    name: "Squirtle",
    type: ["Water"],
    height: "0.5 m",
    weight: "9.0 kg",
    description: "After birth, its back swells and hardens into a shell. Powerfully sprays foam from its mouth.",
    image: "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/other/official-artwork/7.png",
    stats: {
      hp: 44,
      attack: 48,
      defense: 65,
      speed: 43
    }
  },
  {
    id: 8,
    name: "Wartortle",
    type: ["Water"],
    height: "1.0 m",
    weight: "22.5 kg",
    description: "Often hides in water to stalk unwary prey. For swimming fast, it moves its ears to maintain balance.",
    image: "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/other/official-artwork/8.png",
    stats: {
      hp: 59,
      attack: 63,
      defense: 80,
      speed: 58
    }
  },
  {
    id: 9,
    name: "Blastoise",
    type: ["Water"],
    height: "1.6 m",
    weight: "85.5 kg",
    description: "A brutal Pokémon with pressurized water jets on its shell. They are used for high speed tackles.",
    image: "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/other/official-artwork/9.png",
    stats: {
      hp: 79,
      attack: 83,
      defense: 100,
      speed: 78
    }
  },
  {
    id: 25,
    name: "Pikachu",
    type: ["Electric"],
    height: "0.4 m",
    weight: "6.0 kg",
    description: "When several of these Pokémon gather, their electricity could build and cause lightning storms.",
    image: "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/other/official-artwork/25.png",
    stats: {
      hp: 35,
      attack: 55,
      defense: 40,
      speed: 90
    }
  },
  {
    id: 10,
    name: "Caterpie",
    type: ["Bug"],
    height: "0.3 m",
    weight: "2.9 kg",
    description: "Its feet have suction cups designed to stick to any surface. It tenaciously climbs trees to forage.",
    image: "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/other/official-artwork/10.png",
    stats: {
      hp: 45,
      attack: 30,
      defense: 35,
      speed: 45
    }
  },
  {
    id: 11,
    name: "Metapod",
    type: ["Bug"],
    height: "0.7 m",
    weight: "9.9 kg",
    description: "This Pokémon is vulnerable to attack while its shell is soft, exposing its weak and tender body.",
    image: "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/other/official-artwork/11.png",
    stats: {
      hp: 50,
      attack: 20,
      defense: 55,
      speed: 30
    }
  },
  {
    id: 12,
    name: "Butterfree",
    type: ["Bug", "Flying"],
    height: "1.1 m",
    weight: "32.0 kg",
    description: "It loves the honey of flowers and can locate flower patches that have even tiny amounts of pollen.",
    image: "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/other/official-artwork/12.png",
    stats: {
      hp: 60,
      attack: 45,
      defense: 50,
      speed: 70
    }
  },
  {
    id: 16,
    name: "Pidgey",
    type: ["Normal", "Flying"],
    height: "0.3 m",
    weight: "1.8 kg",
    description: "A common sight in forests and woods. It flaps its wings at ground level to kick up blinding sand.",
    image: "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/other/official-artwork/16.png",
    stats: {
      hp: 40,
      attack: 45,
      defense: 40,
      speed: 56
    }
  },
  {
    id: 19,
    name: "Rattata",
    type: ["Normal"],
    height: "0.3 m",
    weight: "3.5 kg",
    description: "Bites anything when it attacks. Small and very quick, it is a common sight in many places.",
    image: "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/other/official-artwork/19.png",
    stats: {
      hp: 30,
      attack: 56,
      defense: 35,
      speed: 72
    }
  },
  {
    id: 104,
    name: "Cubone",
    type: ["Ground"],
    height: "0.4 m",
    weight: "6.5 kg",
    description: "Because it never removes its skull helmet, no one has ever seen this Pokémon's real face.",
    image: "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/other/official-artwork/104.png",
    stats: {
      hp: 50,
      attack: 50,
      defense: 95,
      speed: 35
    }
  },
  {
    id: 143,
    name: "Snorlax",
    type: ["Normal"],
    height: "2.1 m",
    weight: "460.0 kg",
    description: "Its stomach can digest any kind of food, even if it happens to be moldy or rotten.",
    image: "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/other/official-artwork/143.png",
    stats: {
      hp: 160,
      attack: 110,
      defense: 65,
      speed: 30
    }
  },
  {
    id: 150,
    name: "Mewtwo",
    type: ["Psychic"],
    height: "2.0 m",
    weight: "122.0 kg",
    description: "It was created by a scientist after years of horrific gene splicing and DNA engineering experiments.",
    image: "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/other/official-artwork/150.png",
    stats: {
      hp: 106,
      attack: 110,
      defense: 90,
      speed: 130
    }
  },
  {
    id: 151,
    name: "Mew",
    type: ["Psychic"],
    height: "0.4 m",
    weight: "4.0 kg",
    description: "When viewed through a microscope, this Pokémon's short, fine, delicate hair can be seen.",
    image: "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/other/official-artwork/151.png",
    stats: {
      hp: 100,
      attack: 100,
      defense: 100,
      speed: 100
    }
  }
];