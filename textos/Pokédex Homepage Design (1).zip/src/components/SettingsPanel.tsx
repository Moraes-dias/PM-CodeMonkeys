import React from 'react';
import { X } from 'lucide-react';
import { Button } from './ui/button';
import { Card } from './ui/card';
import { Switch } from './ui/switch';
import { Slider } from './ui/slider';

interface SettingsPanelProps {
  isOpen: boolean;
  onClose: () => void;
  darkMode: boolean;
  setDarkMode: (enabled: boolean) => void;
  volume: number;
  setVolume: (volume: number) => void;
  musicEnabled: boolean;
  setMusicEnabled: (enabled: boolean) => void;
}

export function SettingsPanel({
  isOpen,
  onClose,
  darkMode,
  setDarkMode,
  volume,
  setVolume,
  musicEnabled,
  setMusicEnabled
}: SettingsPanelProps) {
  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50">
      <Card className="bg-gradient-to-b from-gray-800 to-gray-900 text-white p-6 rounded-xl border-4 border-gray-600 shadow-2xl max-w-md w-full mx-4">
        <div className="flex justify-between items-center mb-6">
          <h2 className="text-xl font-mono text-green-400">CONFIGURAÇÕES</h2>
          <Button
            onClick={onClose}
            size="icon"
            className="bg-red-600 hover:bg-red-700"
          >
            <X className="w-4 h-4" />
          </Button>
        </div>

        <div className="space-y-6">
          {/* Dark Mode Toggle */}
          <div className="flex items-center justify-between">
            <div>
              <div className="text-green-400 font-mono">MODO ESCURO</div>
              <div className="text-gray-400 text-sm">Ativar tema escuro</div>
            </div>
            <Switch
              checked={darkMode}
              onCheckedChange={setDarkMode}
            />
          </div>

          {/* Music Toggle */}
          <div className="flex items-center justify-between">
            <div>
              <div className="text-green-400 font-mono">MÚSICA</div>
              <div className="text-gray-400 text-sm">Ativar música de fundo</div>
            </div>
            <Switch
              checked={musicEnabled}
              onCheckedChange={setMusicEnabled}
            />
          </div>

          {/* Volume Control */}
          <div>
            <div className="flex items-center justify-between mb-2">
              <div className="text-green-400 font-mono">VOLUME</div>
              <div className="text-gray-400 text-sm">{volume}%</div>
            </div>
            <Slider
              value={[volume]}
              onValueChange={(value) => setVolume(value[0])}
              max={100}
              step={5}
              className="w-full"
            />
          </div>

          {/* Pokédex Info */}
          <div className="border-t border-gray-600 pt-4">
            <div className="text-green-400 font-mono text-sm mb-2">INFORMAÇÕES DO SISTEMA</div>
            <div className="space-y-1 text-gray-400 text-xs font-mono">
              <div>VERSÃO: 1.0.0</div>
              <div>POKÉMON REGISTRADOS: 10</div>
              <div>SISTEMA: ONLINE</div>
              <div>BATERIA: 98%</div>
            </div>
          </div>

          {/* Close Button */}
          <Button
            onClick={onClose}
            className="w-full bg-red-600 hover:bg-red-700 font-mono"
          >
            FECHAR
          </Button>
        </div>
      </Card>
    </div>
  );
}