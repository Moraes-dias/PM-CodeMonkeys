import { useState } from 'react';
import { Header } from "./components/Header";
import { HeroSection } from "./components/HeroSection";
import { Footer } from "./components/Footer";
import { PokedexPage } from "./components/PokedexPage";

export default function App() {
  const [currentPage, setCurrentPage] = useState<'home' | 'pokedex'>('home');

  if (currentPage === 'pokedex') {
    return <PokedexPage onBack={() => setCurrentPage('home')} />;
  }

  return (
    <div className="min-h-screen flex flex-col relative bg-red-600">
      {/* Left Border Extension */}
      <div className="absolute left-0 top-0 bottom-0 w-16 sm:w-24 lg:w-32 bg-gradient-to-r from-red-700 via-red-600 to-red-700 z-10"></div>
      
      {/* Right Border Extension */}
      <div className="absolute right-0 top-0 bottom-0 w-16 sm:w-24 lg:w-32 bg-gradient-to-l from-red-700 via-red-600 to-red-700 z-10"></div>
      
      <Header currentPage={currentPage} setCurrentPage={setCurrentPage} />
      <div className="flex-1">
        <HeroSection />
      </div>
      <Footer />
    </div>
  );
}